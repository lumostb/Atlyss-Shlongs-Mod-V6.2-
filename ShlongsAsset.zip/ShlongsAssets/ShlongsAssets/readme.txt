Mod release v6.1
Atlyss Mod for BepInEx that adds dicks to player characters!

Made by TemtemLover (Limpid Plume).
Assets by Bokonus.

To install - put the folder "ShlongAssets" into Atlyss/BepInEx/plugins/<placehere> 
Do it if your mod manager doesn't seem to load the mod - unpack this zip manually to the specified folder.

Controls: 
CTRL+E - Toggle Errection
CTRL+N/B Increase/Decrease size.
ALT+N/B Increase/Decrease Ball Size if applicable
CTRL+F - Toggle Futa mode.
CTRL+H/J - Shift through cock options
CTRL+C - Set pants override mode (see dick even through pants, clipping obviously)

Open any game menu to bring out the mouse - inventory, quest, w/e
Then:
Hold ALT + CTRL and move the mouse to adjust position of the shlong.
HOLD ALT + CTRL and use mouse scrollwheel to adjust vertical rotation of the shlong
